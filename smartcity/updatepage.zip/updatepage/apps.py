from django.apps import AppConfig


class UpdatepageConfig(AppConfig):
    name = 'updatepage'
